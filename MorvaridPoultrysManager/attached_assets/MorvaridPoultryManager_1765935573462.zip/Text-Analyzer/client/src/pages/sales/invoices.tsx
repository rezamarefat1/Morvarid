import { useState } from "react";
import { FileText, Search, Download, Calendar, Phone, Clock, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import EmptyState from "@/components/shared/EmptyState";
import { useData } from "@/context/DataContext";
import { 
  toPersianDigits, 
  formatPersianTime, 
  formatPersianDateShort 
} from "@/lib/persian-utils";

export default function SalesInvoices() {
  const { farms, invoices, users } = useData();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterFarm, setFilterFarm] = useState<string>("all");

  const filteredInvoices = invoices
    .filter((invoice) => {
      const matchesSearch = 
        invoice.customerName.includes(searchQuery) || 
        invoice.invoiceNumber.includes(searchQuery) ||
        (invoice.customerPhone && invoice.customerPhone.includes(searchQuery));
      const matchesFarm = filterFarm === "all" || invoice.farmId === filterFarm;
      return matchesSearch && matchesFarm;
    })
    .slice(-100)
    .reverse();

  const totalAmount = filteredInvoices.reduce((sum, i) => sum + i.totalAmount, 0);

  const exportToExcel = () => {
    const data = filteredInvoices.map((invoice) => {
      const farm = farms.find((f) => f.id === invoice.farmId);
      const operator = users.find((u) => u.id === invoice.operatorId);
      return {
        "شماره حواله": invoice.invoiceNumber,
        "تاریخ": invoice.date,
        "ساعت": invoice.time,
        "مشتری": invoice.customerName,
        "تلفن": invoice.customerPhone || "-",
        "فارم": farm?.name || "-",
        "اپراتور": operator?.fullName || "-",
        "محصولات": invoice.products.map((p) => `${p.productName}: ${p.quantity}`).join(", "),
        "مبلغ کل": invoice.totalAmount,
        "دیروزی": invoice.isYesterday ? "بله" : "خیر",
      };
    });

    const headers = Object.keys(data[0] || {});
    const csvContent = [
      headers.join(","),
      ...data.map((row) => headers.map((h) => `"${row[h as keyof typeof row]}"`).join(",")),
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `invoices-${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
  };

  return (
    <AppLayout>
      <PageHeader
        title="لیست حواله‌ها"
        description={`${toPersianDigits(filteredInvoices.length)} حواله - جمع کل: ${toPersianDigits(totalAmount.toLocaleString())} تومان`}
        actions={
          <Button onClick={exportToExcel} variant="outline" data-testid="button-export-excel">
            <Download className="w-4 h-4 ml-2" />
            خروجی اکسل
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجو بر اساس نام، شماره حواله یا تلفن..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
            data-testid="input-search-sales-invoices"
          />
        </div>
        <Select value={filterFarm} onValueChange={setFilterFarm}>
          <SelectTrigger className="w-48" data-testid="select-filter-farm">
            <Filter className="w-4 h-4 ml-2" />
            <SelectValue placeholder="فیلتر فارم" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه فارم‌ها</SelectItem>
            {farms.filter((f) => f.isActive).map((farm) => (
              <SelectItem key={farm.id} value={farm.id}>{farm.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filteredInvoices.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="حواله‌ای یافت نشد"
          description="نتیجه‌ای برای فیلترهای انتخابی یافت نشد"
        />
      ) : (
        <div className="space-y-3">
          {filteredInvoices.map((invoice) => {
            const farm = farms.find((f) => f.id === invoice.farmId);
            const operator = users.find((u) => u.id === invoice.operatorId);
            
            return (
              <Card 
                key={invoice.id} 
                className={`p-4 ${
                  invoice.isYesterday 
                    ? "border-amber-200 bg-amber-50/50 dark:border-amber-800 dark:bg-amber-950/20" 
                    : ""
                }`}
                data-testid={`sales-invoice-card-${invoice.id}`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="font-semibold">{invoice.customerName}</p>
                      {invoice.isYesterday && (
                        <Badge variant="secondary" className="text-xs bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300">
                          دیروزی
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5" />
                        {toPersianDigits(invoice.invoiceNumber)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {formatPersianDateShort(invoice.date)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {formatPersianTime(invoice.time)}
                      </span>
                      {invoice.customerPhone && (
                        <span className="flex items-center gap-1">
                          <Phone className="w-3.5 h-3.5" />
                          {toPersianDigits(invoice.customerPhone)}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <Badge variant="outline" className="text-xs">
                        {farm?.name}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {operator?.fullName}
                      </Badge>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {invoice.products.map((product, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {product.productName}: {toPersianDigits(product.quantity)} × {toPersianDigits(product.unitPrice.toLocaleString())}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="text-left sm:text-right">
                    <p className="text-xl font-bold text-primary">
                      {toPersianDigits(invoice.totalAmount.toLocaleString())}
                    </p>
                    <p className="text-sm text-muted-foreground">تومان</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </AppLayout>
  );
}
