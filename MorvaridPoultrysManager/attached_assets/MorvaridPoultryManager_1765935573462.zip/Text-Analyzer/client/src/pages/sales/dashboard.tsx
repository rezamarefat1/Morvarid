import { BarChart3, FileText, TrendingUp, Building2, Calendar } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import StatsCard from "@/components/shared/StatsCard";
import { useData } from "@/context/DataContext";
import { 
  toPersianDigits, 
  formatPersianTime, 
  getCurrentPersianDate,
  formatPersianDateShort,
  farmTypeLabels 
} from "@/lib/persian-utils";

export default function SalesDashboard() {
  const { farms, invoices, productionRecords, getStats } = useData();
  const stats = getStats();
  const today = getCurrentPersianDate();

  const last10DaysInvoices = invoices.slice(-20).reverse();

  const totalSalesToday = invoices
    .filter((i) => i.date === today)
    .reduce((sum, i) => sum + i.totalAmount, 0);

  const farmStats = farms.filter((f) => f.isActive).map((farm) => {
    const farmInvoices = invoices.filter((i) => i.farmId === farm.id && i.date === today);
    const farmProduction = productionRecords
      .filter((r) => r.farmId === farm.id && r.date === today)
      .reduce((sum, r) => sum + Object.values(r.products || {}).reduce((a, b) => a + b, 0), 0);
    
    return {
      ...farm,
      todayInvoices: farmInvoices.length,
      todaySales: farmInvoices.reduce((sum, i) => sum + i.totalAmount, 0),
      todayProduction: farmProduction,
    };
  });

  return (
    <AppLayout>
      <PageHeader 
        title="داشبورد فروش"
        description={`گزارش روز: ${formatPersianDateShort(today)}`}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="فروش امروز"
          value={`${toPersianDigits((totalSalesToday / 1000000).toFixed(1))} میلیون`}
          icon={TrendingUp}
          variant="primary"
        />
        <StatsCard
          title="تعداد حواله‌ها"
          value={stats.todayInvoices}
          icon={FileText}
          variant="success"
        />
        <StatsCard
          title="تولید امروز"
          value={`${toPersianDigits(stats.todayProduction)} شانه`}
          icon={BarChart3}
          variant="warning"
        />
        <StatsCard
          title="فارم‌های فعال"
          value={stats.totalFarms}
          icon={Building2}
          variant="default"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <Building2 className="w-4 h-4 text-primary" />
              عملکرد فارم‌ها
            </h2>
          </div>

          <div className="space-y-3">
            {farmStats.map((farm) => (
              <div 
                key={farm.id} 
                className="p-3 rounded-lg border border-border"
                data-testid={`farm-stats-${farm.id}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${
                      farm.type === "morvaridi" ? "bg-primary" : "bg-amber-500"
                    }`} />
                    <span className="font-medium text-sm">{farm.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      {farmTypeLabels[farm.type]}
                    </Badge>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="text-center p-2 bg-muted/50 rounded">
                    <p className="text-xs text-muted-foreground">تولید</p>
                    <p className="font-medium">{toPersianDigits(farm.todayProduction)}</p>
                  </div>
                  <div className="text-center p-2 bg-muted/50 rounded">
                    <p className="text-xs text-muted-foreground">حواله</p>
                    <p className="font-medium">{toPersianDigits(farm.todayInvoices)}</p>
                  </div>
                  <div className="text-center p-2 bg-muted/50 rounded">
                    <p className="text-xs text-muted-foreground">فروش</p>
                    <p className="font-medium text-primary">
                      {toPersianDigits((farm.todaySales / 1000000).toFixed(1))}M
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />
              آخرین حواله‌ها
            </h2>
          </div>

          {last10DaysInvoices.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">هنوز حواله‌ای ثبت نشده است</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {last10DaysInvoices.slice(0, 10).map((invoice) => {
                const farm = farms.find((f) => f.id === invoice.farmId);
                return (
                  <div 
                    key={invoice.id} 
                    className={`flex items-center justify-between p-3 rounded-lg border ${
                      invoice.isYesterday 
                        ? "border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30" 
                        : "border-border"
                    }`}
                  >
                    <div>
                      <p className="font-medium text-sm">{invoice.customerName}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{farm?.name}</span>
                        <span>•</span>
                        <span>{formatPersianTime(invoice.time)}</span>
                        {invoice.isYesterday && (
                          <Badge variant="secondary" className="text-xs bg-amber-100 text-amber-700">
                            دیروزی
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-primary text-sm">
                        {toPersianDigits(invoice.totalAmount.toLocaleString())}
                      </p>
                      <p className="text-xs text-muted-foreground">تومان</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </AppLayout>
  );
}
