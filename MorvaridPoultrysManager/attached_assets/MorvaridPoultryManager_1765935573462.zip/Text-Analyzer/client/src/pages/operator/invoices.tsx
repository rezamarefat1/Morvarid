import { useState } from "react";
import { Plus, Edit2, Trash2, FileText, Phone, Clock, Search, X } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import EmptyState from "@/components/shared/EmptyState";
import ConfirmDialog from "@/components/shared/ConfirmDialog";
import { useAuth } from "@/context/AuthContext";
import { useData } from "@/context/DataContext";
import { 
  toPersianDigits, 
  toEnglishDigits,
  formatPersianTime, 
  getCurrentPersianDate,
  getCurrentPersianTime,
  generateInvoiceNumber,
  formatPersianDateShort 
} from "@/lib/persian-utils";
import type { Invoice, InvoiceProduct } from "@shared/schema";

const invoiceFormSchema = z.object({
  customerName: z.string().min(2, "نام مشتری الزامی است"),
  customerPhone: z.string().optional(),
  isYesterday: z.boolean(),
  notes: z.string().optional(),
});

type InvoiceFormData = z.infer<typeof invoiceFormSchema>;

export default function OperatorInvoices() {
  const { user } = useAuth();
  const { farms, products, invoices, addInvoice, updateInvoice, deleteInvoice } = useData();
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [invoiceProducts, setInvoiceProducts] = useState<InvoiceProduct[]>([]);

  const assignedFarm = farms.find((f) => f.id === user?.assignedFarmId);
  const today = getCurrentPersianDate();

  const farmProducts = products.filter((p) => {
    if (!p.isActive) return false;
    if (!p.farmIds || p.farmIds.length === 0) return true;
    return p.farmIds.includes(assignedFarm?.id || "");
  });

  const myInvoices = invoices
    .filter((i) => i.operatorId === user?.id)
    .filter((i) => 
      i.customerName.includes(searchQuery) || 
      i.invoiceNumber.includes(searchQuery)
    )
    .slice(-50)
    .reverse();

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      customerName: "",
      customerPhone: "",
      isYesterday: false,
      notes: "",
    },
  });

  const openCreateDialog = () => {
    form.reset({
      customerName: "",
      customerPhone: "",
      isYesterday: false,
      notes: "",
    });
    setInvoiceProducts([]);
    setEditingInvoice(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (invoice: Invoice) => {
    form.reset({
      customerName: invoice.customerName,
      customerPhone: invoice.customerPhone || "",
      isYesterday: invoice.isYesterday,
      notes: invoice.notes || "",
    });
    setInvoiceProducts(invoice.products);
    setEditingInvoice(invoice);
    setIsDialogOpen(true);
  };

  const addProductToInvoice = () => {
    if (farmProducts.length === 0) return;
    const firstProduct = farmProducts[0];
    setInvoiceProducts((prev) => [
      ...prev,
      {
        productId: firstProduct.id,
        productName: firstProduct.name,
        quantity: 1,
        unitPrice: 150000,
      },
    ]);
  };

  const updateInvoiceProduct = (index: number, field: keyof InvoiceProduct, value: string | number) => {
    setInvoiceProducts((prev) => {
      const updated = [...prev];
      if (field === "productId") {
        const product = products.find((p) => p.id === value);
        if (product) {
          updated[index] = {
            ...updated[index],
            productId: product.id,
            productName: product.name,
          };
        }
      } else {
        updated[index] = { ...updated[index], [field]: value };
      }
      return updated;
    });
  };

  const removeInvoiceProduct = (index: number) => {
    setInvoiceProducts((prev) => prev.filter((_, i) => i !== index));
  };

  const calculateTotal = () => {
    return invoiceProducts.reduce((sum, p) => sum + p.quantity * p.unitPrice, 0);
  };

  const onSubmit = (data: InvoiceFormData) => {
    if (!assignedFarm || !user) return;

    if (invoiceProducts.length === 0) {
      return;
    }

    const invoiceData = {
      invoiceNumber: editingInvoice?.invoiceNumber || generateInvoiceNumber(),
      farmId: assignedFarm.id,
      operatorId: user.id,
      customerName: data.customerName,
      customerPhone: data.customerPhone || null,
      date: today,
      time: getCurrentPersianTime(),
      products: invoiceProducts,
      totalAmount: calculateTotal(),
      isYesterday: data.isYesterday,
      notes: data.notes || null,
    };

    if (editingInvoice) {
      updateInvoice(editingInvoice.id, invoiceData);
    } else {
      addInvoice(invoiceData);
    }
    setIsDialogOpen(false);
  };

  const handleDelete = () => {
    if (deleteConfirm) {
      deleteInvoice(deleteConfirm);
      setDeleteConfirm(null);
    }
  };

  if (!assignedFarm) {
    return (
      <AppLayout>
        <PageHeader title="مدیریت حواله‌ها" />
        <Card className="p-8 text-center">
          <div className="text-muted-foreground">
            <p>هیچ فارمی به شما تخصیص داده نشده است.</p>
          </div>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <PageHeader
        title="حواله‌های من"
        description={assignedFarm.name}
        actions={
          <Button onClick={openCreateDialog} data-testid="button-add-invoice">
            <Plus className="w-4 h-4 ml-2" />
            حواله جدید
          </Button>
        }
      />

      <div className="mb-4">
        <div className="relative max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی حواله..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
            data-testid="input-search-invoices"
          />
        </div>
      </div>

      {myInvoices.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="حواله‌ای یافت نشد"
          description={searchQuery ? "نتیجه‌ای یافت نشد" : "هنوز حواله‌ای ثبت نکرده‌اید"}
          action={!searchQuery ? { label: "ثبت حواله", onClick: openCreateDialog } : undefined}
        />
      ) : (
        <div className="space-y-3">
          {myInvoices.map((invoice) => (
            <Card 
              key={invoice.id} 
              className={`p-4 ${
                invoice.isYesterday 
                  ? "border-amber-200 bg-amber-50/50 dark:border-amber-800 dark:bg-amber-950/20" 
                  : ""
              }`}
              data-testid={`invoice-card-${invoice.id}`}
            >
              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium">{invoice.customerName}</p>
                    {invoice.isYesterday && (
                      <Badge variant="secondary" className="text-xs bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300">
                        دیروزی
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span>{toPersianDigits(invoice.invoiceNumber)}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatPersianTime(invoice.time)}
                    </span>
                    {invoice.customerPhone && (
                      <span className="flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        {toPersianDigits(invoice.customerPhone)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-left">
                  <p className="font-bold text-primary">
                    {toPersianDigits(invoice.totalAmount.toLocaleString())} تومان
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatPersianDateShort(invoice.date)}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-1 mb-3">
                {invoice.products.map((product, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {product.productName}: {toPersianDigits(product.quantity)}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-border">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => openEditDialog(invoice)}
                  data-testid={`button-edit-invoice-${invoice.id}`}
                >
                  <Edit2 className="w-3 h-3 ml-1" />
                  ویرایش
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => setDeleteConfirm(invoice.id)}
                  data-testid={`button-delete-invoice-${invoice.id}`}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingInvoice ? "ویرایش حواله" : "ثبت حواله جدید"}
            </DialogTitle>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="customerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نام مشتری</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="نام مشتری" data-testid="input-customer-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="customerPhone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>شماره تماس (اختیاری)</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="09..." data-testid="input-customer-phone" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <div className="flex items-center justify-between mb-2">
                  <FormLabel>محصولات</FormLabel>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addProductToInvoice}
                    data-testid="button-add-product-line"
                  >
                    <Plus className="w-3 h-3 ml-1" />
                    افزودن
                  </Button>
                </div>

                {invoiceProducts.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4 border border-dashed border-border rounded-lg">
                    هنوز محصولی اضافه نشده است
                  </p>
                ) : (
                  <div className="space-y-2">
                    {invoiceProducts.map((item, index) => (
                      <div key={index} className="flex items-center gap-2 p-2 border border-border rounded-lg">
                        <Select
                          value={item.productId}
                          onValueChange={(v) => updateInvoiceProduct(index, "productId", v)}
                        >
                          <SelectTrigger className="flex-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {farmProducts.map((p) => (
                              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => updateInvoiceProduct(index, "quantity", parseInt(e.target.value) || 0)}
                          className="w-20 text-center"
                          placeholder="تعداد"
                        />
                        <Input
                          type="number"
                          value={item.unitPrice}
                          onChange={(e) => updateInvoiceProduct(index, "unitPrice", parseInt(e.target.value) || 0)}
                          className="w-28 text-center"
                          placeholder="قیمت"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeInvoiceProduct(index)}
                          className="shrink-0"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}

                {invoiceProducts.length > 0 && (
                  <div className="mt-3 p-3 bg-primary/5 rounded-lg flex items-center justify-between">
                    <span className="font-medium">جمع کل:</span>
                    <span className="text-lg font-bold text-primary">
                      {toPersianDigits(calculateTotal().toLocaleString())} تومان
                    </span>
                  </div>
                )}
              </div>

              <FormField
                control={form.control}
                name="isYesterday"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between p-3 border border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30 rounded-lg">
                    <FormLabel className="text-amber-700 dark:text-amber-400">
                      این حواله مربوط به دیروز است
                    </FormLabel>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-is-yesterday"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>توضیحات (اختیاری)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="توضیحات اضافی..."
                        className="resize-none"
                        rows={2}
                        data-testid="textarea-invoice-notes"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-4">
                <Button 
                  type="submit" 
                  className="flex-1" 
                  disabled={invoiceProducts.length === 0}
                  data-testid="button-save-invoice"
                >
                  {editingInvoice ? "ذخیره تغییرات" : "ثبت حواله"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  انصراف
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
        title="حذف حواله"
        description="آیا از حذف این حواله اطمینان دارید؟"
        confirmLabel="حذف"
        variant="destructive"
        onConfirm={handleDelete}
      />
    </AppLayout>
  );
}
