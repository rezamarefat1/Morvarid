import { useState } from "react";
import { Save, Loader2, CheckCircle, Egg } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import { useAuth } from "@/context/AuthContext";
import { useData } from "@/context/DataContext";
import { 
  toPersianDigits, 
  toEnglishDigits, 
  getCurrentPersianDate, 
  formatPersianDateShort 
} from "@/lib/persian-utils";

export default function OperatorRecord() {
  const { user } = useAuth();
  const { farms, products, productionRecords, addProductionRecord } = useData();
  const { toast } = useToast();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [productAmounts, setProductAmounts] = useState<Record<string, number>>({});
  const [notes, setNotes] = useState("");

  const assignedFarm = farms.find((f) => f.id === user?.assignedFarmId);
  const today = getCurrentPersianDate();

  const farmProducts = products.filter((p) => {
    if (!p.isActive) return false;
    if (!p.farmIds || p.farmIds.length === 0) return true;
    return p.farmIds.includes(assignedFarm?.id || "");
  });

  const todayRecord = productionRecords.find(
    (r) => r.operatorId === user?.id && r.date === today && r.farmId === assignedFarm?.id
  );

  const handleAmountChange = (productId: string, value: string) => {
    const numValue = parseInt(toEnglishDigits(value)) || 0;
    setProductAmounts((prev) => ({ ...prev, [productId]: numValue }));
  };

  const calculateTotal = () => {
    return Object.values(productAmounts).reduce((sum, val) => sum + val, 0);
  };

  const handleSubmit = async () => {
    if (!assignedFarm || !user) {
      toast({
        title: "خطا",
        description: "فارم تخصیص داده نشده است",
        variant: "destructive",
      });
      return;
    }

    if (calculateTotal() === 0) {
      toast({
        title: "خطا",
        description: "حداقل یک محصول باید مقدار داشته باشد",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 500));

      addProductionRecord({
        farmId: assignedFarm.id,
        operatorId: user.id,
        date: today,
        products: productAmounts,
        previousInventory: {},
        currentInventory: {},
        notes: notes || null,
      });

      toast({
        title: "ثبت شد",
        description: "آمار تولید روزانه با موفقیت ثبت شد",
      });

      setProductAmounts({});
      setNotes("");
    } catch {
      toast({
        title: "خطا",
        description: "خطا در ثبت آمار",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!assignedFarm) {
    return (
      <AppLayout>
        <PageHeader title="ثبت آمار روزانه" />
        <Card className="p-8 text-center">
          <div className="text-muted-foreground">
            <p className="mb-2">هیچ فارمی به شما تخصیص داده نشده است.</p>
            <p className="text-sm">لطفاً با مدیر سیستم تماس بگیرید.</p>
          </div>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <PageHeader 
        title="ثبت آمار روزانه"
        description={`${assignedFarm.name} - ${formatPersianDateShort(today)}`}
      />

      {todayRecord && (
        <Card className="p-4 mb-6 bg-emerald-50 border-emerald-200 dark:bg-emerald-950/30 dark:border-emerald-800">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            <div>
              <p className="font-medium text-emerald-700 dark:text-emerald-400">
                آمار امروز قبلاً ثبت شده است
              </p>
              <p className="text-sm text-emerald-600 dark:text-emerald-500">
                مجموع: {toPersianDigits(Object.values(todayRecord.products || {}).reduce((a, b) => a + b, 0))} شانه
              </p>
            </div>
          </div>
        </Card>
      )}

      <Card className="p-4 mb-6">
        <h2 className="font-semibold mb-4 flex items-center gap-2">
          <Egg className="w-4 h-4 text-primary" />
          ثبت تولید محصولات
        </h2>

        <div className="space-y-4">
          {farmProducts.map((product) => (
            <div 
              key={product.id} 
              className="flex items-center justify-between gap-4 p-3 rounded-lg border border-border bg-muted/30"
            >
              <div className="flex-1">
                <p className="font-medium text-sm">{product.name}</p>
                <p className="text-xs text-muted-foreground">واحد: {product.unit}</p>
              </div>
              <div className="w-32">
                <Input
                  type="text"
                  inputMode="numeric"
                  placeholder="۰"
                  value={productAmounts[product.id] ? toPersianDigits(productAmounts[product.id]) : ""}
                  onChange={(e) => handleAmountChange(product.id, e.target.value)}
                  className="text-center text-lg font-medium"
                  data-testid={`input-product-${product.id}`}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 rounded-lg bg-primary/5 border border-primary/20">
          <div className="flex items-center justify-between">
            <span className="font-medium">مجموع تولید:</span>
            <span className="text-2xl font-bold text-primary">
              {toPersianDigits(calculateTotal())} شانه
            </span>
          </div>
        </div>
      </Card>

      <Card className="p-4 mb-6">
        <h2 className="font-semibold mb-3">یادداشت (اختیاری)</h2>
        <Textarea
          placeholder="توضیحات اضافی درباره تولید امروز..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="resize-none"
          rows={3}
          data-testid="textarea-notes"
        />
      </Card>

      <Button
        onClick={handleSubmit}
        disabled={isSubmitting || calculateTotal() === 0}
        className="w-full"
        size="lg"
        data-testid="button-submit-record"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-4 h-4 ml-2 animate-spin" />
            در حال ثبت...
          </>
        ) : (
          <>
            <Save className="w-4 h-4 ml-2" />
            ثبت آمار روزانه
          </>
        )}
      </Button>
    </AppLayout>
  );
}
