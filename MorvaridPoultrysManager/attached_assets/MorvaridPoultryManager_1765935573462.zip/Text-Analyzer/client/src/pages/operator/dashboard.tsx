import { Building2, FileText, Egg, Clock, Plus, ClipboardList } from "lucide-react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import StatsCard from "@/components/shared/StatsCard";
import { useAuth } from "@/context/AuthContext";
import { useData } from "@/context/DataContext";
import { toPersianDigits, formatPersianTime, getCurrentPersianDate, formatPersianDateShort } from "@/lib/persian-utils";

export default function OperatorDashboard() {
  const { user } = useAuth();
  const { farms, invoices, productionRecords, products } = useData();
  
  const assignedFarm = farms.find((f) => f.id === user?.assignedFarmId);
  const today = getCurrentPersianDate();
  
  const myInvoices = invoices
    .filter((i) => i.operatorId === user?.id)
    .slice(-5)
    .reverse();
    
  const todayRecords = productionRecords.filter(
    (r) => r.operatorId === user?.id && r.date === today
  );

  const todayProduction = todayRecords.reduce((sum, r) => {
    return sum + Object.values(r.products || {}).reduce((a, b) => a + b, 0);
  }, 0);

  const myTodayInvoices = invoices.filter(
    (i) => i.operatorId === user?.id && i.date === today
  );

  return (
    <AppLayout>
      <PageHeader 
        title={`خوش آمدید، ${user?.fullName}`}
        description={`امروز: ${formatPersianDateShort(today)}`}
      />

      {assignedFarm && (
        <Card className="p-4 mb-6 bg-primary/5 border-primary/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-full">
              <Building2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">فارم شما</p>
              <p className="font-semibold">{assignedFarm.name}</p>
            </div>
            <Badge variant="default" className="mr-auto">
              {assignedFarm.location}
            </Badge>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <StatsCard
          title="تولید امروز"
          value={`${toPersianDigits(todayProduction)} شانه`}
          icon={Egg}
          variant="primary"
        />
        <StatsCard
          title="حواله‌های امروز"
          value={myTodayInvoices.length}
          icon={FileText}
          variant="success"
        />
        <StatsCard
          title="محصولات فعال"
          value={products.filter((p) => p.isActive).length}
          icon={ClipboardList}
          variant="default"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">دسترسی سریع</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Link href="/operator/record">
              <a className="flex flex-col items-center gap-2 p-4 rounded-lg border border-border hover-elevate transition-colors">
                <div className="p-3 bg-primary/10 rounded-full">
                  <ClipboardList className="w-6 h-6 text-primary" />
                </div>
                <span className="text-sm font-medium">ثبت آمار روزانه</span>
              </a>
            </Link>
            <Link href="/operator/invoices">
              <a className="flex flex-col items-center gap-2 p-4 rounded-lg border border-border hover-elevate transition-colors">
                <div className="p-3 bg-emerald-500/10 rounded-full">
                  <Plus className="w-6 h-6 text-emerald-600" />
                </div>
                <span className="text-sm font-medium">ثبت حواله جدید</span>
              </a>
            </Link>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">آخرین حواله‌های من</h2>
            <Link href="/operator/invoices">
              <a className="text-xs text-primary hover:underline">مشاهده همه</a>
            </Link>
          </div>

          {myInvoices.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">هنوز حواله‌ای ثبت نکرده‌اید</p>
            </div>
          ) : (
            <div className="space-y-2">
              {myInvoices.map((invoice) => (
                <div 
                  key={invoice.id} 
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    invoice.isYesterday 
                      ? "border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30" 
                      : "border-border bg-muted/30"
                  }`}
                >
                  <div>
                    <p className="font-medium text-sm">{invoice.customerName}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      <span>{formatPersianTime(invoice.time)}</span>
                      {invoice.isYesterday && (
                        <Badge variant="secondary" className="text-xs bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300">
                          دیروزی
                        </Badge>
                      )}
                    </div>
                  </div>
                  <p className="font-medium text-sm text-primary">
                    {toPersianDigits(invoice.totalAmount.toLocaleString())} ت
                  </p>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </AppLayout>
  );
}
