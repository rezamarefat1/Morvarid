import { Link } from "wouter";
import { Home, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="p-8 max-w-md w-full text-center">
        <div className="flex flex-col items-center gap-4">
          <div className="p-4 bg-amber-100 dark:bg-amber-900/30 rounded-full">
            <AlertTriangle className="w-8 h-8 text-amber-600 dark:text-amber-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground mb-2">
              صفحه یافت نشد
            </h1>
            <p className="text-muted-foreground">
              صفحه‌ای که به دنبال آن هستید وجود ندارد یا دسترسی به آن ندارید.
            </p>
          </div>
          <Link href="/">
            <Button className="mt-4" data-testid="button-go-home">
              <Home className="w-4 h-4 ml-2" />
              بازگشت به صفحه اصلی
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  );
}
