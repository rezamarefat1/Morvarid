import { useEffect, useState } from "react";
import { Egg } from "lucide-react";

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimating(false);
      setTimeout(onComplete, 300);
    }, 1500);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div 
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-primary via-emerald-600 to-emerald-700 transition-opacity duration-300 ${
        isAnimating ? "opacity-100" : "opacity-0"
      }`}
    >
      <div className="flex flex-col items-center gap-6">
        <div className="relative">
          <div className="absolute inset-0 bg-white/20 rounded-full blur-xl animate-pulse" />
          <div className="relative bg-white/10 backdrop-blur-sm rounded-full p-6 border border-white/20">
            <Egg className="w-16 h-16 text-white animate-pulse" />
          </div>
        </div>
        
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white mb-2">
            مرغداری مروارید
          </h1>
          <p className="text-white/80 text-sm">
            سیستم مدیریت یکپارچه
          </p>
        </div>

        <div className="flex gap-1.5 mt-4">
          <span className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
          <span className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
          <span className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
        </div>
      </div>

      <p className="absolute bottom-8 text-white/50 text-xs">
        مدیریت هوشمند فارم‌های تخم‌مرغ
      </p>
    </div>
  );
}
