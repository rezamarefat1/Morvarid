import { useState } from "react";
import { History, Calendar, Egg, Building2, User, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import EmptyState from "@/components/shared/EmptyState";
import { useData } from "@/context/DataContext";
import { 
  toPersianDigits, 
  formatPersianDateShort,
  farmTypeLabels 
} from "@/lib/persian-utils";

export default function HistoryPage() {
  const { farms, productionRecords, users } = useData();
  const [filterFarm, setFilterFarm] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState("");

  const filteredRecords = productionRecords
    .filter((record) => {
      const matchesFarm = filterFarm === "all" || record.farmId === filterFarm;
      const matchesDate = !dateFilter || record.date.includes(dateFilter);
      return matchesFarm && matchesDate;
    })
    .slice(-100)
    .reverse();

  const groupedByDate = filteredRecords.reduce((acc, record) => {
    if (!acc[record.date]) {
      acc[record.date] = [];
    }
    acc[record.date].push(record);
    return acc;
  }, {} as Record<string, typeof filteredRecords>);

  const exportToExcel = () => {
    const data = filteredRecords.map((record) => {
      const farm = farms.find((f) => f.id === record.farmId);
      const operator = users.find((u) => u.id === record.operatorId);
      const totalProduction = Object.values(record.products || {}).reduce((a, b) => a + b, 0);
      
      return {
        "تاریخ": record.date,
        "فارم": farm?.name || "-",
        "اپراتور": operator?.fullName || "-",
        "کل تولید": totalProduction,
        "محصولات": JSON.stringify(record.products),
        "یادداشت": record.notes || "-",
      };
    });

    const headers = Object.keys(data[0] || {});
    const csvContent = [
      headers.join(","),
      ...data.map((row) => headers.map((h) => `"${row[h as keyof typeof row]}"`).join(",")),
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `production-history-${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
  };

  return (
    <AppLayout>
      <PageHeader
        title="تاریخچه آمار تولید"
        description={`${toPersianDigits(filteredRecords.length)} رکورد`}
        actions={
          <Button onClick={exportToExcel} variant="outline" data-testid="button-export-history">
            <Download className="w-4 h-4 ml-2" />
            خروجی اکسل
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          placeholder="فیلتر تاریخ (مثال: 1403/09)"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          className="max-w-xs"
          data-testid="input-filter-date"
        />
        <Select value={filterFarm} onValueChange={setFilterFarm}>
          <SelectTrigger className="w-48" data-testid="select-filter-history-farm">
            <Building2 className="w-4 h-4 ml-2" />
            <SelectValue placeholder="فیلتر فارم" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه فارم‌ها</SelectItem>
            {farms.map((farm) => (
              <SelectItem key={farm.id} value={farm.id}>{farm.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filteredRecords.length === 0 ? (
        <EmptyState
          icon={History}
          title="رکوردی یافت نشد"
          description="هنوز آماری ثبت نشده یا فیلترهای انتخابی نتیجه‌ای ندارند"
        />
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedByDate).map(([date, records]) => {
            const totalForDay = records.reduce(
              (sum, r) => sum + Object.values(r.products || {}).reduce((a, b) => a + b, 0),
              0
            );
            
            return (
              <div key={date}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>{formatPersianDateShort(date)}</span>
                  </div>
                  <Badge variant="secondary">
                    مجموع: {toPersianDigits(totalForDay)} شانه
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {records.map((record) => {
                    const farm = farms.find((f) => f.id === record.farmId);
                    const operator = users.find((u) => u.id === record.operatorId);
                    const total = Object.values(record.products || {}).reduce((a, b) => a + b, 0);

                    return (
                      <Card key={record.id} className="p-4" data-testid={`history-record-${record.id}`}>
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Building2 className="w-4 h-4 text-primary" />
                              <span className="font-medium text-sm">{farm?.name}</span>
                            </div>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <User className="w-3 h-3" />
                              <span>{operator?.fullName}</span>
                            </div>
                          </div>
                          <Badge 
                            variant={farm?.type === "morvaridi" ? "default" : "secondary"}
                            className="text-xs"
                          >
                            {farm ? farmTypeLabels[farm.type] : ""}
                          </Badge>
                        </div>

                        <div className="p-3 bg-primary/5 rounded-lg mb-3">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground flex items-center gap-1">
                              <Egg className="w-3.5 h-3.5" />
                              کل تولید
                            </span>
                            <span className="text-lg font-bold text-primary">
                              {toPersianDigits(total)} شانه
                            </span>
                          </div>
                        </div>

                        <div className="space-y-1 text-sm">
                          {Object.entries(record.products || {}).map(([productId, amount]) => (
                            <div key={productId} className="flex items-center justify-between text-muted-foreground">
                              <span>محصول {toPersianDigits(productId.slice(-4))}</span>
                              <span>{toPersianDigits(amount as number)}</span>
                            </div>
                          ))}
                        </div>

                        {record.notes && (
                          <p className="mt-3 pt-3 border-t border-border text-xs text-muted-foreground">
                            {record.notes}
                          </p>
                        )}
                      </Card>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppLayout>
  );
}
