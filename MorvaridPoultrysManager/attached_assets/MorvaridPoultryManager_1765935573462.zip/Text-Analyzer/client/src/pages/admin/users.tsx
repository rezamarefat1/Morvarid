import { useState } from "react";
import { Plus, Edit2, Trash2, User, Eye, EyeOff, Search } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import EmptyState from "@/components/shared/EmptyState";
import ConfirmDialog from "@/components/shared/ConfirmDialog";
import { useData } from "@/context/DataContext";
import { roleLabels } from "@/lib/persian-utils";
import type { User as UserType, UserRole } from "@shared/schema";

const userFormSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل ۳ کاراکتر باشد"),
  password: z.string().min(4, "رمز عبور باید حداقل ۴ کاراکتر باشد"),
  fullName: z.string().min(2, "نام کامل الزامی است"),
  role: z.enum(["admin", "sales", "operator"]),
  isActive: z.boolean(),
  assignedFarmId: z.string().nullable(),
});

type UserFormData = z.infer<typeof userFormSchema>;

export default function AdminUsers() {
  const { users, farms, addUser, updateUser, deleteUser } = useData();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserType | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState("");

  const form = useForm<UserFormData>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      username: "",
      password: "",
      fullName: "",
      role: "operator",
      isActive: true,
      assignedFarmId: null,
    },
  });

  const filteredUsers = users.filter((user) =>
    user.fullName.includes(searchQuery) || 
    user.username.includes(searchQuery)
  );

  const openCreateDialog = () => {
    form.reset({
      username: "",
      password: "",
      fullName: "",
      role: "operator",
      isActive: true,
      assignedFarmId: null,
    });
    setEditingUser(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (user: UserType) => {
    form.reset({
      username: user.username,
      password: user.password,
      fullName: user.fullName,
      role: user.role,
      isActive: user.isActive,
      assignedFarmId: user.assignedFarmId,
    });
    setEditingUser(user);
    setIsDialogOpen(true);
  };

  const onSubmit = (data: UserFormData) => {
    if (editingUser) {
      updateUser(editingUser.id, data);
    } else {
      addUser(data as Omit<UserType, "id" | "createdAt">);
    }
    setIsDialogOpen(false);
  };

  const handleDelete = () => {
    if (deleteConfirm) {
      deleteUser(deleteConfirm);
      setDeleteConfirm(null);
    }
  };

  const togglePasswordVisibility = (userId: string) => {
    setShowPasswords((prev) => ({ ...prev, [userId]: !prev[userId] }));
  };

  const roleVariants: Record<UserRole, "default" | "secondary" | "outline"> = {
    admin: "default",
    sales: "secondary",
    operator: "outline",
  };

  return (
    <AppLayout>
      <PageHeader
        title="مدیریت کاربران"
        description="ایجاد و مدیریت کاربران سیستم"
        actions={
          <Button onClick={openCreateDialog} data-testid="button-add-user">
            <Plus className="w-4 h-4 ml-2" />
            کاربر جدید
          </Button>
        }
      />

      <div className="mb-4">
        <div className="relative max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی کاربر..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
            data-testid="input-search-users"
          />
        </div>
      </div>

      {filteredUsers.length === 0 ? (
        <EmptyState
          icon={User}
          title="کاربری یافت نشد"
          description={searchQuery ? "نتیجه‌ای برای جستجوی شما یافت نشد" : "هنوز کاربری ایجاد نشده است"}
          action={!searchQuery ? { label: "ایجاد کاربر", onClick: openCreateDialog } : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredUsers.map((user) => {
            const assignedFarm = farms.find((f) => f.id === user.assignedFarmId);
            return (
              <Card key={user.id} className="p-4" data-testid={`user-card-${user.id}`}>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium ${
                      user.isActive 
                        ? "bg-primary/10 text-primary" 
                        : "bg-muted text-muted-foreground"
                    }`}>
                      {user.fullName.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{user.fullName}</p>
                      <p className="text-xs text-muted-foreground">{user.username}</p>
                    </div>
                  </div>
                  <Badge variant={roleVariants[user.role]} className="text-xs">
                    {roleLabels[user.role]}
                  </Badge>
                </div>

                <div className="space-y-2 text-sm mb-4">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">رمز عبور:</span>
                    <div className="flex items-center gap-1">
                      <span className="font-mono text-xs">
                        {showPasswords[user.id] ? user.password : "••••••"}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-6 h-6"
                        onClick={() => togglePasswordVisibility(user.id)}
                      >
                        {showPasswords[user.id] ? (
                          <EyeOff className="w-3 h-3" />
                        ) : (
                          <Eye className="w-3 h-3" />
                        )}
                      </Button>
                    </div>
                  </div>
                  
                  {user.role === "operator" && (
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">فارم:</span>
                      <span>{assignedFarm?.name || "تخصیص داده نشده"}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">وضعیت:</span>
                    <Badge variant={user.isActive ? "default" : "secondary"} className="text-xs">
                      {user.isActive ? "فعال" : "غیرفعال"}
                    </Badge>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-3 border-t border-border">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => openEditDialog(user)}
                    data-testid={`button-edit-user-${user.id}`}
                  >
                    <Edit2 className="w-3 h-3 ml-1" />
                    ویرایش
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => setDeleteConfirm(user.id)}
                    data-testid={`button-delete-user-${user.id}`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingUser ? "ویرایش کاربر" : "ایجاد کاربر جدید"}
            </DialogTitle>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نام کامل</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="نام و نام خانوادگی" data-testid="input-fullname" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نام کاربری</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="نام کاربری برای ورود" data-testid="input-user-username" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>رمز عبور</FormLabel>
                    <FormControl>
                      <Input {...field} type="text" placeholder="رمز عبور" data-testid="input-user-password" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نقش</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-role">
                          <SelectValue placeholder="انتخاب نقش" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="admin">مدیر سیستم</SelectItem>
                        <SelectItem value="sales">کارشناس فروش</SelectItem>
                        <SelectItem value="operator">اپراتور</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {form.watch("role") === "operator" && (
                <FormField
                  control={form.control}
                  name="assignedFarmId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>فارم تخصیص‌یافته</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger data-testid="select-farm">
                            <SelectValue placeholder="انتخاب فارم" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="">بدون فارم</SelectItem>
                          {farms.filter((f) => f.isActive).map((farm) => (
                            <SelectItem key={farm.id} value={farm.id}>
                              {farm.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <FormLabel>وضعیت فعال</FormLabel>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-is-active"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1" data-testid="button-save-user">
                  {editingUser ? "ذخیره تغییرات" : "ایجاد کاربر"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  انصراف
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
        title="حذف کاربر"
        description="آیا از حذف این کاربر اطمینان دارید؟ این عمل قابل بازگشت نیست."
        confirmLabel="حذف"
        variant="destructive"
        onConfirm={handleDelete}
      />
    </AppLayout>
  );
}
