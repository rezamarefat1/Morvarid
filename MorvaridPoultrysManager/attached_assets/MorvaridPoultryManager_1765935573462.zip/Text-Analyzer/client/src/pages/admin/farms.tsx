import { useState } from "react";
import { Plus, Edit2, Trash2, Building2, MapPin, Users, Search } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import EmptyState from "@/components/shared/EmptyState";
import ConfirmDialog from "@/components/shared/ConfirmDialog";
import { useData } from "@/context/DataContext";
import { toPersianDigits, farmTypeLabels } from "@/lib/persian-utils";
import type { Farm, FarmType } from "@shared/schema";

const farmFormSchema = z.object({
  name: z.string().min(2, "نام فارم الزامی است"),
  type: z.enum(["morvaridi", "motafarreqe"]),
  location: z.string().optional(),
  capacity: z.number().min(0).optional(),
  isActive: z.boolean(),
  operatorId: z.string().nullable(),
});

type FarmFormData = z.infer<typeof farmFormSchema>;

export default function AdminFarms() {
  const { farms, users, addFarm, updateFarm, deleteFarm } = useData();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingFarm, setEditingFarm] = useState<Farm | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<FarmType | "all">("all");

  const operators = users.filter((u) => u.role === "operator" && u.isActive);

  const form = useForm<FarmFormData>({
    resolver: zodResolver(farmFormSchema),
    defaultValues: {
      name: "",
      type: "morvaridi",
      location: "",
      capacity: 0,
      isActive: true,
      operatorId: null,
    },
  });

  const filteredFarms = farms.filter((farm) => {
    const matchesSearch = farm.name.includes(searchQuery) || 
      (farm.location && farm.location.includes(searchQuery));
    const matchesType = filterType === "all" || farm.type === filterType;
    return matchesSearch && matchesType;
  });

  const openCreateDialog = () => {
    form.reset({
      name: "",
      type: "morvaridi",
      location: "",
      capacity: 0,
      isActive: true,
      operatorId: null,
    });
    setEditingFarm(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (farm: Farm) => {
    form.reset({
      name: farm.name,
      type: farm.type,
      location: farm.location || "",
      capacity: farm.capacity || 0,
      isActive: farm.isActive,
      operatorId: farm.operatorId,
    });
    setEditingFarm(farm);
    setIsDialogOpen(true);
  };

  const onSubmit = (data: FarmFormData) => {
    if (editingFarm) {
      updateFarm(editingFarm.id, data);
    } else {
      addFarm(data as Omit<Farm, "id" | "createdAt">);
    }
    setIsDialogOpen(false);
  };

  const handleDelete = () => {
    if (deleteConfirm) {
      deleteFarm(deleteConfirm);
      setDeleteConfirm(null);
    }
  };

  return (
    <AppLayout>
      <PageHeader
        title="مدیریت فارم‌ها"
        description="ایجاد و مدیریت فارم‌های مرغداری"
        actions={
          <Button onClick={openCreateDialog} data-testid="button-add-farm">
            <Plus className="w-4 h-4 ml-2" />
            فارم جدید
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی فارم..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
            data-testid="input-search-farms"
          />
        </div>
        <Select value={filterType} onValueChange={(v) => setFilterType(v as FarmType | "all")}>
          <SelectTrigger className="w-40" data-testid="select-filter-type">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه فارم‌ها</SelectItem>
            <SelectItem value="morvaridi">مرواریدی</SelectItem>
            <SelectItem value="motafarreqe">متفرقه</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredFarms.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="فارمی یافت نشد"
          description={searchQuery || filterType !== "all" ? "نتیجه‌ای یافت نشد" : "هنوز فارمی ایجاد نشده است"}
          action={!searchQuery && filterType === "all" ? { label: "ایجاد فارم", onClick: openCreateDialog } : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFarms.map((farm) => {
            const operator = users.find((u) => u.id === farm.operatorId);
            return (
              <Card key={farm.id} className="p-4" data-testid={`farm-card-${farm.id}`}>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      farm.type === "morvaridi" 
                        ? "bg-primary/10 text-primary" 
                        : "bg-amber-500/10 text-amber-600"
                    }`}>
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{farm.name}</p>
                      <Badge 
                        variant={farm.type === "morvaridi" ? "default" : "secondary"} 
                        className="text-xs mt-1"
                      >
                        {farmTypeLabels[farm.type]}
                      </Badge>
                    </div>
                  </div>
                  <Badge variant={farm.isActive ? "default" : "outline"} className="text-xs">
                    {farm.isActive ? "فعال" : "غیرفعال"}
                  </Badge>
                </div>

                <div className="space-y-2 text-sm mb-4">
                  {farm.location && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{farm.location}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Users className="w-3.5 h-3.5" />
                    <span>{operator ? operator.fullName : "بدون اپراتور"}</span>
                  </div>

                  {farm.capacity && (
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">ظرفیت:</span>
                      <span className="font-medium">{toPersianDigits(farm.capacity)} قطعه</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-3 border-t border-border">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => openEditDialog(farm)}
                    data-testid={`button-edit-farm-${farm.id}`}
                  >
                    <Edit2 className="w-3 h-3 ml-1" />
                    ویرایش
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => setDeleteConfirm(farm.id)}
                    data-testid={`button-delete-farm-${farm.id}`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingFarm ? "ویرایش فارم" : "ایجاد فارم جدید"}
            </DialogTitle>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نام فارم</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="مثال: فارم مروارید ۱" data-testid="input-farm-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نوع فارم</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-farm-type">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="morvaridi">مرواریدی</SelectItem>
                        <SelectItem value="motafarreqe">متفرقه</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>موقعیت</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="شهر یا منطقه" data-testid="input-farm-location" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="capacity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ظرفیت (تعداد قطعه)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        placeholder="ظرفیت فارم"
                        data-testid="input-farm-capacity"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="operatorId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>اپراتور مسئول</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl>
                        <SelectTrigger data-testid="select-farm-operator">
                          <SelectValue placeholder="انتخاب اپراتور" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="">بدون اپراتور</SelectItem>
                        {operators.map((op) => (
                          <SelectItem key={op.id} value={op.id}>
                            {op.fullName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <FormLabel>وضعیت فعال</FormLabel>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-farm-active"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1" data-testid="button-save-farm">
                  {editingFarm ? "ذخیره تغییرات" : "ایجاد فارم"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  انصراف
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
        title="حذف فارم"
        description="آیا از حذف این فارم اطمینان دارید؟ این عمل قابل بازگشت نیست."
        confirmLabel="حذف"
        variant="destructive"
        onConfirm={handleDelete}
      />
    </AppLayout>
  );
}
