import { Building2, Users, FileText, Egg, TrendingUp, Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import StatsCard from "@/components/shared/StatsCard";
import { useData } from "@/context/DataContext";
import { toPersianDigits, formatPersianTime, getCurrentPersianDate, formatPersianDateShort } from "@/lib/persian-utils";

export default function AdminPanel() {
  const { getStats, invoices, farms, users } = useData();
  const stats = getStats();

  const recentInvoices = invoices.slice(-5).reverse();

  return (
    <AppLayout>
      <PageHeader 
        title="داشبورد مدیریت" 
        description={`امروز: ${formatPersianDateShort(getCurrentPersianDate())}`}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="کل فارم‌ها"
          value={stats.totalFarms}
          icon={Building2}
          description={`${toPersianDigits(stats.morvaridiFarms)} مرواریدی - ${toPersianDigits(stats.motafarreqeFarms)} متفرقه`}
          variant="primary"
        />
        <StatsCard
          title="کاربران فعال"
          value={stats.activeUsers}
          icon={Users}
          variant="success"
        />
        <StatsCard
          title="حواله‌های امروز"
          value={stats.todayInvoices}
          icon={FileText}
          variant="warning"
        />
        <StatsCard
          title="تولید امروز"
          value={`${toPersianDigits(stats.todayProduction)} شانه`}
          icon={Egg}
          variant="default"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              آخرین حواله‌ها
            </h2>
          </div>
          
          {recentInvoices.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">هنوز حواله‌ای ثبت نشده است</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentInvoices.map((invoice) => (
                <div 
                  key={invoice.id} 
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    invoice.isYesterday 
                      ? "border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30" 
                      : "border-border bg-muted/30"
                  }`}
                  data-testid={`invoice-card-${invoice.id}`}
                >
                  <div>
                    <p className="font-medium text-sm">{invoice.customerName}</p>
                    <p className="text-xs text-muted-foreground">
                      {toPersianDigits(invoice.invoiceNumber)}
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-sm text-primary">
                      {toPersianDigits(invoice.totalAmount.toLocaleString())} تومان
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 justify-end">
                      <Clock className="w-3 h-3" />
                      {formatPersianTime(invoice.time)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <Building2 className="w-4 h-4 text-primary" />
              وضعیت فارم‌ها
            </h2>
          </div>
          
          <div className="space-y-3">
            {farms.filter(f => f.isActive).map((farm) => {
              const operator = users.find(u => u.id === farm.operatorId);
              return (
                <div 
                  key={farm.id} 
                  className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/30"
                  data-testid={`farm-status-${farm.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      farm.type === "morvaridi" ? "bg-primary" : "bg-amber-500"
                    }`} />
                    <div>
                      <p className="font-medium text-sm">{farm.name}</p>
                      <p className="text-xs text-muted-foreground">{farm.location}</p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">
                      {operator ? operator.fullName : "بدون اپراتور"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      ظرفیت: {toPersianDigits(farm.capacity || 0)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </AppLayout>
  );
}
