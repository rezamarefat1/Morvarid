import { useState } from "react";
import { Plus, Edit2, Trash2, Package, Search } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/shared/PageHeader";
import EmptyState from "@/components/shared/EmptyState";
import ConfirmDialog from "@/components/shared/ConfirmDialog";
import { useData } from "@/context/DataContext";
import type { Product } from "@shared/schema";

const productFormSchema = z.object({
  name: z.string().min(2, "نام محصول الزامی است"),
  unit: z.string().min(1, "واحد الزامی است"),
  isActive: z.boolean(),
  farmIds: z.array(z.string()),
});

type ProductFormData = z.infer<typeof productFormSchema>;

export default function AdminProducts() {
  const { products, farms, addProduct, updateProduct, deleteProduct } = useData();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const form = useForm<ProductFormData>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      name: "",
      unit: "شانه",
      isActive: true,
      farmIds: [],
    },
  });

  const filteredProducts = products.filter((product) =>
    product.name.includes(searchQuery)
  );

  const openCreateDialog = () => {
    form.reset({
      name: "",
      unit: "شانه",
      isActive: true,
      farmIds: [],
    });
    setEditingProduct(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (product: Product) => {
    form.reset({
      name: product.name,
      unit: product.unit,
      isActive: product.isActive,
      farmIds: product.farmIds || [],
    });
    setEditingProduct(product);
    setIsDialogOpen(true);
  };

  const onSubmit = (data: ProductFormData) => {
    if (editingProduct) {
      updateProduct(editingProduct.id, data);
    } else {
      addProduct(data as Omit<Product, "id" | "createdAt">);
    }
    setIsDialogOpen(false);
  };

  const handleDelete = () => {
    if (deleteConfirm) {
      deleteProduct(deleteConfirm);
      setDeleteConfirm(null);
    }
  };

  const activeFarms = farms.filter((f) => f.isActive);

  return (
    <AppLayout>
      <PageHeader
        title="مدیریت محصولات"
        description="تعریف و مدیریت محصولات قابل فروش"
        actions={
          <Button onClick={openCreateDialog} data-testid="button-add-product">
            <Plus className="w-4 h-4 ml-2" />
            محصول جدید
          </Button>
        }
      />

      <div className="mb-4">
        <div className="relative max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی محصول..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
            data-testid="input-search-products"
          />
        </div>
      </div>

      {filteredProducts.length === 0 ? (
        <EmptyState
          icon={Package}
          title="محصولی یافت نشد"
          description={searchQuery ? "نتیجه‌ای یافت نشد" : "هنوز محصولی ایجاد نشده است"}
          action={!searchQuery ? { label: "ایجاد محصول", onClick: openCreateDialog } : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map((product) => {
            const assignedFarms = farms.filter((f) => product.farmIds?.includes(f.id));
            return (
              <Card key={product.id} className="p-4" data-testid={`product-card-${product.id}`}>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      product.isActive 
                        ? "bg-primary/10 text-primary" 
                        : "bg-muted text-muted-foreground"
                    }`}>
                      <Package className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{product.name}</p>
                      <p className="text-xs text-muted-foreground">واحد: {product.unit}</p>
                    </div>
                  </div>
                  <Badge variant={product.isActive ? "default" : "outline"} className="text-xs">
                    {product.isActive ? "فعال" : "غیرفعال"}
                  </Badge>
                </div>

                <div className="mb-4">
                  <p className="text-xs text-muted-foreground mb-2">فارم‌های مرتبط:</p>
                  <div className="flex flex-wrap gap-1">
                    {assignedFarms.length > 0 ? (
                      assignedFarms.map((farm) => (
                        <Badge key={farm.id} variant="secondary" className="text-xs">
                          {farm.name}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-xs text-muted-foreground">همه فارم‌ها</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-3 border-t border-border">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => openEditDialog(product)}
                    data-testid={`button-edit-product-${product.id}`}
                  >
                    <Edit2 className="w-3 h-3 ml-1" />
                    ویرایش
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => setDeleteConfirm(product.id)}
                    data-testid={`button-delete-product-${product.id}`}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? "ویرایش محصول" : "ایجاد محصول جدید"}
            </DialogTitle>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نام محصول</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="مثال: تخم مرغ درجه یک" data-testid="input-product-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="unit"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>واحد اندازه‌گیری</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="مثال: شانه، عدد، کیلو" data-testid="input-product-unit" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="farmIds"
                render={() => (
                  <FormItem>
                    <FormLabel>فارم‌های مرتبط</FormLabel>
                    <div className="space-y-2 max-h-40 overflow-y-auto p-2 border border-border rounded-lg">
                      {activeFarms.map((farm) => (
                        <FormField
                          key={farm.id}
                          control={form.control}
                          name="farmIds"
                          render={({ field }) => (
                            <FormItem className="flex items-center gap-2">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(farm.id)}
                                  onCheckedChange={(checked) => {
                                    const current = field.value || [];
                                    if (checked) {
                                      field.onChange([...current, farm.id]);
                                    } else {
                                      field.onChange(current.filter((id) => id !== farm.id));
                                    }
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="text-sm font-normal !mt-0 cursor-pointer">
                                {farm.name}
                              </FormLabel>
                            </FormItem>
                          )}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      اگر هیچ فارمی انتخاب نشود، محصول برای همه فارم‌ها قابل استفاده است
                    </p>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <FormLabel>وضعیت فعال</FormLabel>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="switch-product-active"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1" data-testid="button-save-product">
                  {editingProduct ? "ذخیره تغییرات" : "ایجاد محصول"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  انصراف
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
        title="حذف محصول"
        description="آیا از حذف این محصول اطمینان دارید؟ این عمل قابل بازگشت نیست."
        confirmLabel="حذف"
        variant="destructive"
        onConfirm={handleDelete}
      />
    </AppLayout>
  );
}
