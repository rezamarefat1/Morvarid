import { createContext, useContext, ReactNode } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Farm, Product, Invoice, ProductionRecord, User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { getCurrentPersianDate } from "@/lib/persian-utils";

interface DataContextType {
  farms: Farm[];
  products: Product[];
  invoices: Invoice[];
  productionRecords: ProductionRecord[];
  users: User[];
  isLoading: boolean;
  addFarm: (farm: Omit<Farm, "id" | "createdAt">) => void;
  updateFarm: (id: string, farm: Partial<Farm>) => void;
  deleteFarm: (id: string) => void;
  addProduct: (product: Omit<Product, "id" | "createdAt">) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addInvoice: (invoice: Omit<Invoice, "id" | "createdAt">) => void;
  updateInvoice: (id: string, invoice: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  addProductionRecord: (record: Omit<ProductionRecord, "id" | "createdAt">) => void;
  addUser: (user: Omit<User, "id" | "createdAt">) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;
  getStats: () => {
    totalFarms: number;
    morvaridiFarms: number;
    motafarreqeFarms: number;
    activeUsers: number;
    todayInvoices: number;
    todayProduction: number;
  };
  refetchAll: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();

  const { data: farms = [], isLoading: farmsLoading } = useQuery<Farm[]>({
    queryKey: ["/api/farms"],
  });

  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: invoices = [], isLoading: invoicesLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  const { data: productionRecords = [], isLoading: recordsLoading } = useQuery<ProductionRecord[]>({
    queryKey: ["/api/production-records"],
  });

  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const isLoading = farmsLoading || productsLoading || invoicesLoading || recordsLoading || usersLoading;

  const createFarmMutation = useMutation({
    mutationFn: (farm: Omit<Farm, "id" | "createdAt">) =>
      apiRequest("POST", "/api/farms", farm),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/farms"] }),
  });

  const updateFarmMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Farm> }) =>
      apiRequest("PATCH", `/api/farms/${id}`, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/farms"] }),
  });

  const deleteFarmMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/farms/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/farms"] }),
  });

  const createProductMutation = useMutation({
    mutationFn: (product: Omit<Product, "id" | "createdAt">) =>
      apiRequest("POST", "/api/products", product),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/products"] }),
  });

  const updateProductMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Product> }) =>
      apiRequest("PATCH", `/api/products/${id}`, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/products"] }),
  });

  const deleteProductMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/products/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/products"] }),
  });

  const createInvoiceMutation = useMutation({
    mutationFn: (invoice: Omit<Invoice, "id" | "createdAt">) =>
      apiRequest("POST", "/api/invoices", invoice),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/invoices"] }),
  });

  const updateInvoiceMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Invoice> }) =>
      apiRequest("PATCH", `/api/invoices/${id}`, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/invoices"] }),
  });

  const deleteInvoiceMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/invoices/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/invoices"] }),
  });

  const createRecordMutation = useMutation({
    mutationFn: (record: Omit<ProductionRecord, "id" | "createdAt">) =>
      apiRequest("POST", "/api/production-records", record),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/production-records"] }),
  });

  const createUserMutation = useMutation({
    mutationFn: (user: Omit<User, "id" | "createdAt">) =>
      apiRequest("POST", "/api/users", user),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/users"] }),
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<User> }) =>
      apiRequest("PATCH", `/api/users/${id}`, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/users"] }),
  });

  const deleteUserMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/users/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/users"] }),
  });

  const addFarm = (farm: Omit<Farm, "id" | "createdAt">) => {
    createFarmMutation.mutate(farm);
  };

  const updateFarm = (id: string, farm: Partial<Farm>) => {
    updateFarmMutation.mutate({ id, data: farm });
  };

  const deleteFarm = (id: string) => {
    deleteFarmMutation.mutate(id);
  };

  const addProduct = (product: Omit<Product, "id" | "createdAt">) => {
    createProductMutation.mutate(product);
  };

  const updateProduct = (id: string, product: Partial<Product>) => {
    updateProductMutation.mutate({ id, data: product });
  };

  const deleteProduct = (id: string) => {
    deleteProductMutation.mutate(id);
  };

  const addInvoice = (invoice: Omit<Invoice, "id" | "createdAt">) => {
    createInvoiceMutation.mutate(invoice);
  };

  const updateInvoice = (id: string, invoice: Partial<Invoice>) => {
    updateInvoiceMutation.mutate({ id, data: invoice });
  };

  const deleteInvoice = (id: string) => {
    deleteInvoiceMutation.mutate(id);
  };

  const addProductionRecord = (record: Omit<ProductionRecord, "id" | "createdAt">) => {
    createRecordMutation.mutate(record);
  };

  const addUser = (user: Omit<User, "id" | "createdAt">) => {
    createUserMutation.mutate(user);
  };

  const updateUser = (id: string, user: Partial<User>) => {
    updateUserMutation.mutate({ id, data: user });
  };

  const deleteUser = (id: string) => {
    deleteUserMutation.mutate(id);
  };

  const getStats = () => {
    const today = getCurrentPersianDate();
    return {
      totalFarms: farms.filter((f) => f.isActive).length,
      morvaridiFarms: farms.filter((f) => f.type === "morvaridi" && f.isActive).length,
      motafarreqeFarms: farms.filter((f) => f.type === "motafarreqe" && f.isActive).length,
      activeUsers: users.filter((u) => u.isActive).length,
      todayInvoices: invoices.filter((i) => i.date === today).length,
      todayProduction: productionRecords
        .filter((r) => r.date === today)
        .reduce((sum, r) => {
          const total = Object.values(r.products || {}).reduce((a, b) => a + b, 0);
          return sum + total;
        }, 0),
    };
  };

  const refetchAll = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/farms"] });
    queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
    queryClient.invalidateQueries({ queryKey: ["/api/production-records"] });
    queryClient.invalidateQueries({ queryKey: ["/api/users"] });
  };

  return (
    <DataContext.Provider
      value={{
        farms,
        products,
        invoices,
        productionRecords,
        users,
        isLoading,
        addFarm,
        updateFarm,
        deleteFarm,
        addProduct,
        updateProduct,
        deleteProduct,
        addInvoice,
        updateInvoice,
        deleteInvoice,
        addProductionRecord,
        addUser,
        updateUser,
        deleteUser,
        getStats,
        refetchAll,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
}
