import { useState } from "react";
import { useLocation, Link } from "wouter";
import { 
  LayoutDashboard, Users, Building2, Package, FileText, 
  BarChart3, Settings, LogOut, Menu, X, Egg, ChevronLeft,
  ClipboardList, History
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/context/AuthContext";
import { roleLabels } from "@/lib/persian-utils";
import type { UserRole } from "@shared/schema";

interface NavItem {
  label: string;
  href: string;
  icon: typeof LayoutDashboard;
  roles: UserRole[];
}

const navItems: NavItem[] = [
  { label: "داشبورد", href: "/admin/panel", icon: LayoutDashboard, roles: ["admin"] },
  { label: "مدیریت کاربران", href: "/admin/users", icon: Users, roles: ["admin"] },
  { label: "مدیریت فارم‌ها", href: "/admin/farms", icon: Building2, roles: ["admin"] },
  { label: "مدیریت محصولات", href: "/admin/products", icon: Package, roles: ["admin"] },
  { label: "داشبورد فروش", href: "/sales/dashboard", icon: BarChart3, roles: ["sales"] },
  { label: "حواله‌ها", href: "/sales/invoices", icon: FileText, roles: ["sales"] },
  { label: "داشبورد", href: "/operator/dashboard", icon: LayoutDashboard, roles: ["operator"] },
  { label: "ثبت آمار روزانه", href: "/operator/record", icon: ClipboardList, roles: ["operator"] },
  { label: "حواله‌های من", href: "/operator/invoices", icon: FileText, roles: ["operator"] },
  { label: "تاریخچه آمار", href: "/history", icon: History, roles: ["admin", "sales", "operator"] },
];

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const filteredNavItems = navItems.filter((item) => 
    user && item.roles.includes(user.role)
  );

  const handleLogout = () => {
    logout();
  };

  const getInitials = (name: string) => {
    return name.split(" ").map((n) => n[0]).join("").slice(0, 2);
  };

  return (
    <div className="min-h-screen bg-background flex">
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 right-4 z-50 lg:hidden"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        data-testid="button-menu-toggle"
      >
        {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </Button>

      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <aside 
        className={`fixed lg:sticky top-0 right-0 h-screen w-64 bg-sidebar border-l border-sidebar-border flex flex-col z-40 transition-transform duration-300 ${
          isSidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        }`}
      >
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 rounded-full p-2">
              <Egg className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="font-bold text-sidebar-foreground text-sm">مرغداری مروارید</h1>
              <p className="text-xs text-muted-foreground">سیستم مدیریت</p>
            </div>
          </div>
        </div>

        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-primary/10 text-primary text-sm font-medium">
                {user ? getInitials(user.fullName) : "?"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sidebar-foreground text-sm truncate">
                {user?.fullName}
              </p>
              <Badge variant="secondary" className="text-xs mt-1">
                {user ? roleLabels[user.role] : ""}
              </Badge>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-3 overflow-y-auto">
          <ul className="space-y-1">
            {filteredNavItems.map((item) => {
              const isActive = location === item.href;
              const Icon = item.icon;
              return (
                <li key={item.href}>
                  <Link href={item.href}>
                    <a
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                        isActive
                          ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                          : "text-sidebar-foreground/80 hover-elevate"
                      }`}
                      onClick={() => setIsSidebarOpen(false)}
                      data-testid={`nav-${item.href.replace(/\//g, "-")}`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                      {isActive && <ChevronLeft className="w-4 h-4 mr-auto" />}
                    </a>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-3 border-t border-sidebar-border">
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
            <span>خروج از سیستم</span>
          </Button>
        </div>
      </aside>

      <main className="flex-1 lg:mr-0">
        <div className="p-4 lg:p-6 pt-16 lg:pt-6">
          {children}
        </div>
      </main>
    </div>
  );
}
