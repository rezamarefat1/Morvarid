import { Card } from "@/components/ui/card";
import { toPersianDigits } from "@/lib/persian-utils";
import type { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: number | string;
  icon: LucideIcon;
  description?: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: "default" | "primary" | "success" | "warning" | "danger";
}

const variantStyles = {
  default: {
    icon: "bg-muted text-muted-foreground",
    value: "text-foreground",
  },
  primary: {
    icon: "bg-primary/10 text-primary",
    value: "text-primary",
  },
  success: {
    icon: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    value: "text-emerald-600 dark:text-emerald-400",
  },
  warning: {
    icon: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    value: "text-amber-600 dark:text-amber-400",
  },
  danger: {
    icon: "bg-destructive/10 text-destructive",
    value: "text-destructive",
  },
};

export default function StatsCard({
  title,
  value,
  icon: Icon,
  description,
  trend,
  variant = "default",
}: StatsCardProps) {
  const styles = variantStyles[variant];
  const displayValue = typeof value === "number" ? toPersianDigits(value) : value;

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <p className="text-sm text-muted-foreground mb-1">{title}</p>
          <p className={`text-2xl font-bold ${styles.value}`}>
            {displayValue}
          </p>
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
          {trend && (
            <div className={`flex items-center gap-1 mt-2 text-xs ${
              trend.isPositive ? "text-emerald-600" : "text-destructive"
            }`}>
              <span>{trend.isPositive ? "+" : "-"}{toPersianDigits(Math.abs(trend.value))}%</span>
              <span className="text-muted-foreground">نسبت به دیروز</span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${styles.icon}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </Card>
  );
}
