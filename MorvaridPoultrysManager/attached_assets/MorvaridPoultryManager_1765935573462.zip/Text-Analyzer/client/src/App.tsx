import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { DataProvider } from "@/context/DataContext";
import { useState, useEffect } from "react";

import SplashScreen from "@/pages/splash";
import LoginPage from "@/pages/login";
import AdminPanel from "@/pages/admin/panel";
import AdminUsers from "@/pages/admin/users";
import AdminFarms from "@/pages/admin/farms";
import AdminProducts from "@/pages/admin/products";
import SalesDashboard from "@/pages/sales/dashboard";
import SalesInvoices from "@/pages/sales/invoices";
import OperatorDashboard from "@/pages/operator/dashboard";
import OperatorRecord from "@/pages/operator/record";
import OperatorInvoices from "@/pages/operator/invoices";
import HistoryPage from "@/pages/history";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ 
  children, 
  allowedRoles 
}: { 
  children: React.ReactNode; 
  allowedRoles?: string[];
}) {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    const defaultRoute = user.role === "admin" ? "/admin/panel" 
      : user.role === "sales" ? "/sales/dashboard" 
      : "/operator/dashboard";
    setLocation(defaultRoute);
    return null;
  }

  return <>{children}</>;
}

function RootRedirect() {
  const { isAuthenticated, user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        setLocation("/login");
      } else if (user) {
        const route = user.role === "admin" ? "/admin/panel" 
          : user.role === "sales" ? "/sales/dashboard" 
          : "/operator/dashboard";
        setLocation(route);
      }
    }
  }, [isAuthenticated, user, isLoading, setLocation]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={RootRedirect} />
      <Route path="/login" component={LoginPage} />
      
      <Route path="/admin/panel">
        <ProtectedRoute allowedRoles={["admin"]}>
          <AdminPanel />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute allowedRoles={["admin"]}>
          <AdminUsers />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/farms">
        <ProtectedRoute allowedRoles={["admin"]}>
          <AdminFarms />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/products">
        <ProtectedRoute allowedRoles={["admin"]}>
          <AdminProducts />
        </ProtectedRoute>
      </Route>

      <Route path="/sales/dashboard">
        <ProtectedRoute allowedRoles={["sales"]}>
          <SalesDashboard />
        </ProtectedRoute>
      </Route>
      <Route path="/sales/invoices">
        <ProtectedRoute allowedRoles={["sales"]}>
          <SalesInvoices />
        </ProtectedRoute>
      </Route>

      <Route path="/operator/dashboard">
        <ProtectedRoute allowedRoles={["operator"]}>
          <OperatorDashboard />
        </ProtectedRoute>
      </Route>
      <Route path="/operator/record">
        <ProtectedRoute allowedRoles={["operator"]}>
          <OperatorRecord />
        </ProtectedRoute>
      </Route>
      <Route path="/operator/invoices">
        <ProtectedRoute allowedRoles={["operator"]}>
          <OperatorInvoices />
        </ProtectedRoute>
      </Route>

      <Route path="/history">
        <ProtectedRoute allowedRoles={["admin", "sales", "operator"]}>
          <HistoryPage />
        </ProtectedRoute>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return <Router />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <DataProvider>
            <AppContent />
            <Toaster />
          </DataProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
