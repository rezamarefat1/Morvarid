import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export type UserRole = "admin" | "sales" | "operator";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().$type<UserRole>(),
  isActive: boolean("is_active").notNull().default(true),
  assignedFarmId: varchar("assigned_farm_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  role: true,
  isActive: true,
  assignedFarmId: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type FarmType = "morvaridi" | "motafarreqe";

export const farms = pgTable("farms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull().$type<FarmType>(),
  location: text("location"),
  capacity: integer("capacity"),
  isActive: boolean("is_active").notNull().default(true),
  operatorId: varchar("operator_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertFarmSchema = createInsertSchema(farms).pick({
  name: true,
  type: true,
  location: true,
  capacity: true,
  isActive: true,
  operatorId: true,
});

export type InsertFarm = z.infer<typeof insertFarmSchema>;
export type Farm = typeof farms.$inferSelect;

export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  unit: text("unit").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  farmIds: text("farm_ids").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
  unit: true,
  isActive: true,
  farmIds: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export const productionRecords = pgTable("production_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farmId: varchar("farm_id").notNull(),
  operatorId: varchar("operator_id").notNull(),
  date: text("date").notNull(),
  products: jsonb("products").notNull().$type<Record<string, number>>(),
  previousInventory: jsonb("previous_inventory").$type<Record<string, number>>(),
  currentInventory: jsonb("current_inventory").$type<Record<string, number>>(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductionRecordSchema = createInsertSchema(productionRecords).pick({
  farmId: true,
  operatorId: true,
  date: true,
  products: true,
  previousInventory: true,
  currentInventory: true,
  notes: true,
});

export type InsertProductionRecord = z.infer<typeof insertProductionRecordSchema>;
export type ProductionRecord = typeof productionRecords.$inferSelect;

export type InvoiceProduct = {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
};

export const invoices = pgTable("invoices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  invoiceNumber: text("invoice_number").notNull().unique(),
  farmId: varchar("farm_id").notNull(),
  operatorId: varchar("operator_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone"),
  date: text("date").notNull(),
  time: text("time").notNull(),
  products: jsonb("products").notNull().$type<InvoiceProduct[]>(),
  totalAmount: integer("total_amount").notNull(),
  isYesterday: boolean("is_yesterday").notNull().default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInvoiceSchema = createInsertSchema(invoices).pick({
  invoiceNumber: true,
  farmId: true,
  operatorId: true,
  customerName: true,
  customerPhone: true,
  date: true,
  time: true,
  products: true,
  totalAmount: true,
  isYesterday: true,
  notes: true,
});

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

export const loginSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل 3 کاراکتر باشد"),
  password: z.string().min(4, "رمز عبور باید حداقل 4 کاراکتر باشد"),
  rememberMe: z.boolean().optional(),
});

export type LoginFormData = z.infer<typeof loginSchema>;
