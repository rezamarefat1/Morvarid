# Design Guidelines: Morvarid Poultry Management System

## Project Overview
**Progressive Web Application (PWA)** for comprehensive poultry farm management with Persian/Farsi RTL interface, supporting three user roles: Admin, Sales, and Operator.

## Language & Direction
- **Language:** Persian/Farsi (RTL)
- **Calendar:** Solar Hijri (Jalali)
- **Font:** Vazirmatn or IranSans
- **Direction:** Right-to-Left throughout entire application

## Design System

### Color Palette
**Primary (Emerald Green):**
- Dark Emerald: Primary buttons, emphasized elements
- Light Emerald: Hover and active states
- Very Light Emerald: Light backgrounds

**Status Colors:**
- Green: Success, confirmation, sufficient inventory
- Red: Errors, warnings, delete actions
- Orange/Amber: Alerts, yesterday's invoices, attention
- Blue: Information, links

**Neutral:**
- Dark Gray: Primary text
- Medium Gray: Secondary text, labels
- Light Gray: Borders, dividers
- White: Card backgrounds
- Very Light Gray: Page backgrounds

### Typography
**Font Sizes:**
- XL: Page titles
- LG: Card and section headings
- Base: Body text
- SM: Labels and descriptions
- XS: Secondary text

**Font Weights:**
- Light: Secondary text
- Regular: Body text
- Medium: Labels
- Bold: Headings and calculated results

### Spacing System
Use 4px base system:
- XS: 4px
- SM: 8px
- MD: 16px
- LG: 24px
- XL: 32px
- 2XL: 48px

### Border Radius
- Small: 4px (small buttons, tags)
- Medium: 8px (inputs, small cards)
- Large: 12px (main cards)
- XL: 16px (modals)
- Full: 9999px (round buttons, avatars)

### Shadows
- Small: Buttons
- Medium: Cards
- Large: Modals and dropdowns

## Layout Structure

### Responsive Breakpoints
- Mobile: 320px - 480px
- Tablet: 481px - 1024px
- Desktop: 1025px+

### Navigation
**Desktop:** Fixed sidebar (right side for RTL)
**Mobile:** Hamburger menu

**Sidebar Elements:**
1. Header with logo and system name
2. User info (avatar + username + role)
3. Main menu with icons
4. Logout button at bottom

## Key Screens

### 1. Splash Screen
- Emerald gradient background (dark to light)
- Centered logo with subtle pulse animation
- System name below logo (large, white font)
- Loading spinner/dots below name
- Display for minimum 1.5 seconds

### 2. Login Screen
**Mobile:** Single column
**Desktop:** Two columns

**Elements:**
- Logo (medium size)
- System name: "سیستم مدیریت مرغداری مروارید"
- Subtitle: "مدیریت هوشمند فارم‌های تخم‌مرغ"
- Username field with user icon (right side)
- Password field with lock icon and show/hide toggle
- "Remember me" checkbox (when biometric not available)
- Biometric login button (purple tint, fingerprint icon)
- Primary login button (emerald green)
- Error messages in red cards with warning icons

### 3. Admin Panel
**Stats Cards:** Display total farms, active users, today's invoices, today's production
**Charts:** Weekly production (bar/line chart with farm filters)
**Recent Activity:** Latest actions list

### 4. Farm Management
**Two Farm Types:**
- Morvaridi (Pearl) farms
- Motafarreqe (Miscellaneous) farms

Cards showing farm details with edit/delete actions, product assignments, operator assignments.

### 5. Daily Production Recording (Operator)
Form with:
- Farm selector
- Date picker (Jalali calendar)
- Product grid with input fields for each product
- Automatic inventory calculation
- Live total calculations
- Submit button

### 6. Invoice Management
Invoice cards showing:
- Customer name and phone
- Sale date and time
- Products with quantities
- Yesterday's invoices highlighted in orange/amber
- Edit/delete actions for operators
- Excel export functionality

### 7. Sales Dashboard
- Analytical charts and graphs
- Invoice search with date range
- Last 10 days invoices display
- Excel export for filtered results

## Components

### Cards
- White background
- Medium shadow
- Large border radius (12px)
- Consistent padding (MD to LG)

### Buttons
**Primary:** Emerald background, white text
**Secondary:** Light emerald background, emerald text
**Danger:** Red background, white text
**States:** Hover lightens, loading shows spinner

### Forms
- Labels above inputs
- Icons on right side (RTL)
- Medium border radius
- Light gray borders
- Focus state with emerald outline

### Tables
- Zebra striping (alternate row colors)
- Hover highlight
- Responsive: Stack on mobile
- Action buttons on left (RTL)

### Modals
- XL border radius
- Large shadow
- Backdrop blur
- Slide-up animation
- Close button (top-right for RTL)

## Animations
- **Minimal usage:** Keep animations subtle
- Fade-in-up for forms
- Shake for errors
- Pulse for loading states
- Smooth transitions (200-300ms)

## Images
**Logo:** Place in header, sidebar, login screen
- Medium size in navigation
- Larger size on login
No hero images needed - this is a utility-focused dashboard application

## RTL Considerations
- All layouts mirror horizontally
- Icons on right side of inputs
- Sidebar on right side
- Text alignment: right
- Number formats: Persian numerals option
- Date formats: Jalali calendar throughout