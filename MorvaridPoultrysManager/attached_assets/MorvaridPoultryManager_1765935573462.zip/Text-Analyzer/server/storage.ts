import { 
  type User, type InsertUser,
  type Farm, type InsertFarm,
  type Product, type InsertProduct,
  type Invoice, type InsertInvoice,
  type ProductionRecord, type InsertProductionRecord 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;

  getFarm(id: string): Promise<Farm | undefined>;
  getFarms(): Promise<Farm[]>;
  createFarm(farm: InsertFarm): Promise<Farm>;
  updateFarm(id: string, farm: Partial<InsertFarm>): Promise<Farm | undefined>;
  deleteFarm(id: string): Promise<boolean>;

  getProduct(id: string): Promise<Product | undefined>;
  getProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  getInvoice(id: string): Promise<Invoice | undefined>;
  getInvoices(): Promise<Invoice[]>;
  getInvoicesByOperator(operatorId: string): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: string, invoice: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: string): Promise<boolean>;

  getProductionRecord(id: string): Promise<ProductionRecord | undefined>;
  getProductionRecords(): Promise<ProductionRecord[]>;
  getProductionRecordsByFarm(farmId: string): Promise<ProductionRecord[]>;
  createProductionRecord(record: InsertProductionRecord): Promise<ProductionRecord>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private farms: Map<string, Farm>;
  private products: Map<string, Product>;
  private invoices: Map<string, Invoice>;
  private productionRecords: Map<string, ProductionRecord>;

  constructor() {
    this.users = new Map();
    this.farms = new Map();
    this.products = new Map();
    this.invoices = new Map();
    this.productionRecords = new Map();

    this.seedData();
  }

  private seedData() {
    const users: User[] = [
      { id: "1", username: "admin", password: "admin123", fullName: "مدیر سیستم", role: "admin", isActive: true, assignedFarmId: null, createdAt: new Date() },
      { id: "2", username: "sales", password: "sales123", fullName: "کارشناس فروش", role: "sales", isActive: true, assignedFarmId: null, createdAt: new Date() },
      { id: "3", username: "operator", password: "op123", fullName: "اپراتور فارم مروارید ۱", role: "operator", isActive: true, assignedFarmId: "farm-1", createdAt: new Date() },
    ];
    users.forEach(u => this.users.set(u.id, u));

    const farms: Farm[] = [
      { id: "farm-1", name: "فارم مروارید ۱", type: "morvaridi", location: "کرج", capacity: 50000, isActive: true, operatorId: "3", createdAt: new Date() },
      { id: "farm-2", name: "فارم مروارید ۲", type: "morvaridi", location: "قزوین", capacity: 40000, isActive: true, operatorId: null, createdAt: new Date() },
      { id: "farm-3", name: "فارم متفرقه ۱", type: "motafarreqe", location: "ساوه", capacity: 30000, isActive: true, operatorId: null, createdAt: new Date() },
    ];
    farms.forEach(f => this.farms.set(f.id, f));

    const products: Product[] = [
      { id: "prod-1", name: "تخم مرغ درجه یک", unit: "شانه", isActive: true, farmIds: ["farm-1", "farm-2"], createdAt: new Date() },
      { id: "prod-2", name: "تخم مرغ درجه دو", unit: "شانه", isActive: true, farmIds: ["farm-1", "farm-2", "farm-3"], createdAt: new Date() },
      { id: "prod-3", name: "تخم مرغ صادراتی", unit: "شانه", isActive: true, farmIds: ["farm-1"], createdAt: new Date() },
    ];
    products.forEach(p => this.products.set(p.id, p));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...updates };
    this.users.set(id, updated);
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  async getFarm(id: string): Promise<Farm | undefined> {
    return this.farms.get(id);
  }

  async getFarms(): Promise<Farm[]> {
    return Array.from(this.farms.values());
  }

  async createFarm(insertFarm: InsertFarm): Promise<Farm> {
    const id = randomUUID();
    const farm: Farm = { ...insertFarm, id, createdAt: new Date() };
    this.farms.set(id, farm);
    return farm;
  }

  async updateFarm(id: string, updates: Partial<InsertFarm>): Promise<Farm | undefined> {
    const farm = this.farms.get(id);
    if (!farm) return undefined;
    const updated = { ...farm, ...updates };
    this.farms.set(id, updated);
    return updated;
  }

  async deleteFarm(id: string): Promise<boolean> {
    return this.farms.delete(id);
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { ...insertProduct, id, createdAt: new Date() };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    const updated = { ...product, ...updates };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  async getInvoice(id: string): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async getInvoices(): Promise<Invoice[]> {
    return Array.from(this.invoices.values());
  }

  async getInvoicesByOperator(operatorId: string): Promise<Invoice[]> {
    return Array.from(this.invoices.values()).filter(i => i.operatorId === operatorId);
  }

  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const id = randomUUID();
    const invoice: Invoice = { ...insertInvoice, id, createdAt: new Date() };
    this.invoices.set(id, invoice);
    return invoice;
  }

  async updateInvoice(id: string, updates: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const invoice = this.invoices.get(id);
    if (!invoice) return undefined;
    const updated = { ...invoice, ...updates };
    this.invoices.set(id, updated);
    return updated;
  }

  async deleteInvoice(id: string): Promise<boolean> {
    return this.invoices.delete(id);
  }

  async getProductionRecord(id: string): Promise<ProductionRecord | undefined> {
    return this.productionRecords.get(id);
  }

  async getProductionRecords(): Promise<ProductionRecord[]> {
    return Array.from(this.productionRecords.values());
  }

  async getProductionRecordsByFarm(farmId: string): Promise<ProductionRecord[]> {
    return Array.from(this.productionRecords.values()).filter(r => r.farmId === farmId);
  }

  async createProductionRecord(insertRecord: InsertProductionRecord): Promise<ProductionRecord> {
    const id = randomUUID();
    const record: ProductionRecord = { ...insertRecord, id, createdAt: new Date() };
    this.productionRecords.set(id, record);
    return record;
  }
}

export const storage = new MemStorage();
