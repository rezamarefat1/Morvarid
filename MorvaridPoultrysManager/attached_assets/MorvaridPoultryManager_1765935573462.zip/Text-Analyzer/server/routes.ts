import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertFarmSchema, insertProductSchema, insertInvoiceSchema, insertProductionRecordSchema, loginSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(data.username);
      
      if (!user || user.password !== data.password || !user.isActive) {
        return res.status(401).json({ message: "نام کاربری یا رمز عبور اشتباه است" });
      }

      const { password, ...userWithoutPassword } = user;
      return res.json({ user: userWithoutPassword });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.get("/api/users", async (_req, res) => {
    const users = await storage.getUsers();
    return res.json(users);
  });

  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    return res.json(user);
  });

  app.post("/api/users", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const existing = await storage.getUserByUsername(data.username);
      if (existing) {
        return res.status(400).json({ message: "نام کاربری قبلاً استفاده شده است" });
      }
      const user = await storage.createUser(data);
      return res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const data = insertUserSchema.partial().parse(req.body);
      const user = await storage.updateUser(req.params.id, data);
      if (!user) {
        return res.status(404).json({ message: "کاربر یافت نشد" });
      }
      return res.json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    const deleted = await storage.deleteUser(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    return res.json({ message: "کاربر حذف شد" });
  });

  app.get("/api/farms", async (_req, res) => {
    const farms = await storage.getFarms();
    return res.json(farms);
  });

  app.get("/api/farms/:id", async (req, res) => {
    const farm = await storage.getFarm(req.params.id);
    if (!farm) {
      return res.status(404).json({ message: "فارم یافت نشد" });
    }
    return res.json(farm);
  });

  app.post("/api/farms", async (req, res) => {
    try {
      const data = insertFarmSchema.parse(req.body);
      const farm = await storage.createFarm(data);
      return res.status(201).json(farm);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.patch("/api/farms/:id", async (req, res) => {
    try {
      const data = insertFarmSchema.partial().parse(req.body);
      const farm = await storage.updateFarm(req.params.id, data);
      if (!farm) {
        return res.status(404).json({ message: "فارم یافت نشد" });
      }
      return res.json(farm);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.delete("/api/farms/:id", async (req, res) => {
    const deleted = await storage.deleteFarm(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "فارم یافت نشد" });
    }
    return res.json({ message: "فارم حذف شد" });
  });

  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    return res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProduct(req.params.id);
    if (!product) {
      return res.status(404).json({ message: "محصول یافت نشد" });
    }
    return res.json(product);
  });

  app.post("/api/products", async (req, res) => {
    try {
      const data = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(data);
      return res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.patch("/api/products/:id", async (req, res) => {
    try {
      const data = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(req.params.id, data);
      if (!product) {
        return res.status(404).json({ message: "محصول یافت نشد" });
      }
      return res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    const deleted = await storage.deleteProduct(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "محصول یافت نشد" });
    }
    return res.json({ message: "محصول حذف شد" });
  });

  app.get("/api/invoices", async (_req, res) => {
    const invoices = await storage.getInvoices();
    return res.json(invoices);
  });

  app.get("/api/invoices/operator/:operatorId", async (req, res) => {
    const invoices = await storage.getInvoicesByOperator(req.params.operatorId);
    return res.json(invoices);
  });

  app.get("/api/invoices/:id", async (req, res) => {
    const invoice = await storage.getInvoice(req.params.id);
    if (!invoice) {
      return res.status(404).json({ message: "حواله یافت نشد" });
    }
    return res.json(invoice);
  });

  app.post("/api/invoices", async (req, res) => {
    try {
      const data = insertInvoiceSchema.parse(req.body);
      const invoice = await storage.createInvoice(data);
      return res.status(201).json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.patch("/api/invoices/:id", async (req, res) => {
    try {
      const data = insertInvoiceSchema.partial().parse(req.body);
      const invoice = await storage.updateInvoice(req.params.id, data);
      if (!invoice) {
        return res.status(404).json({ message: "حواله یافت نشد" });
      }
      return res.json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.delete("/api/invoices/:id", async (req, res) => {
    const deleted = await storage.deleteInvoice(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "حواله یافت نشد" });
    }
    return res.json({ message: "حواله حذف شد" });
  });

  app.get("/api/production-records", async (_req, res) => {
    const records = await storage.getProductionRecords();
    return res.json(records);
  });

  app.get("/api/production-records/farm/:farmId", async (req, res) => {
    const records = await storage.getProductionRecordsByFarm(req.params.farmId);
    return res.json(records);
  });

  app.get("/api/production-records/:id", async (req, res) => {
    const record = await storage.getProductionRecord(req.params.id);
    if (!record) {
      return res.status(404).json({ message: "رکورد یافت نشد" });
    }
    return res.json(record);
  });

  app.post("/api/production-records", async (req, res) => {
    try {
      const data = insertProductionRecordSchema.parse(req.body);
      const record = await storage.createProductionRecord(data);
      return res.status(201).json(record);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "داده‌های ورودی نامعتبر است", errors: error.errors });
      }
      return res.status(500).json({ message: "خطای سرور" });
    }
  });

  app.get("/api/stats", async (_req, res) => {
    const farms = await storage.getFarms();
    const users = await storage.getUsers();
    const invoices = await storage.getInvoices();
    const records = await storage.getProductionRecords();

    const today = new Date().toISOString().split("T")[0];

    const stats = {
      totalFarms: farms.filter(f => f.isActive).length,
      morvaridiFarms: farms.filter(f => f.type === "morvaridi" && f.isActive).length,
      motafarreqeFarms: farms.filter(f => f.type === "motafarreqe" && f.isActive).length,
      activeUsers: users.filter(u => u.isActive).length,
      todayInvoices: invoices.filter(i => i.date === today).length,
      todayProduction: records
        .filter(r => r.date === today)
        .reduce((sum, r) => sum + Object.values(r.products || {}).reduce((a: number, b: number) => a + b, 0), 0),
    };

    return res.json(stats);
  });

  return httpServer;
}
